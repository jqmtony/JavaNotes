package carClient.Test;

import java.io.IOException;

public class regexTest {
	public static void main(String[] args) throws IOException {
			/*String chooseFun ="1+2";
			System.out.println("chooseFun\t"+chooseFun);
			String[] params = chooseFun.split("\\+");
			for (String string : params) {
				System.out.println(string);
			}*/
			String num = "1";
			int num2 = Integer.parseInt(num);
			System.out.println(num2);
		}
}
